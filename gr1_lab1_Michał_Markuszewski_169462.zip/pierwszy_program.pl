lubi(krowa,trawe).
lubi(ptak,latac).
lubi(ryba,plywac).

