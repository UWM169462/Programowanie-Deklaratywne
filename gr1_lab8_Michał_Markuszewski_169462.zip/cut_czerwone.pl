f0(X,Y):-between(14,16,X),
    between(X,17,Y).
f0(18,18).

f1(X,Y):-!,
    between(14,16,X),
    between(X,17,Y).
f1(18,18).

f2(X,Y):-between(14,16,X),
    !,
    between(X,17,Y).
f2(18,18).

f3(X,Y):-between(14,16,X),
    between(X,17,Y),
    !.
f3(18,18).
