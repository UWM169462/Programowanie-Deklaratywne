%program: zaleznosci
/**/p(a,d).
/**/p(X,Y):-q(X,Z),r(Z,Y).

/**/q(a,b).
/**/q(c,a).

/**/r(a,d).
/**/r(b,c).
